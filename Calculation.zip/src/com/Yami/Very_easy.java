package com.Yami;

public class Very_easy {
	public void start() {
	System.out.println("Very easy 난이도가 선택되었습니다.");
	}

}
