package com.Yami;

import java.util.Scanner;
import java.util.concurrent.*;
import java.util.concurrent.Executors;

public class Practice {

	int score = 0; // 정답 점수

	private int generateRandomNumber(int upperBound) {
		return(int)(Math.random()*upperBound)+1;
	}
	public void start() {
		System.out.println("Practice 난이도가 선택되었습니다.");
		System.out.println("게임 모드를 선택해 주십시오. (예 : 사칙연산을 원하신다면 '4'를 입력)");
		System.out.println("[1.덧셈,뺄셈],[2.곱셈],[3.나눗셈],[4.곱셈,나눗셈],[5.사칙연산]");
		System.out.println("이전화면으로 이동하시고 싶다면 'x'를입력해 주십시오.");

		Scanner scanner = new Scanner(System.in);
		ExecutorService executor = Executors.newSingleThreadExecutor();

		while (true) {
			String input = scanner.nextLine().trim();
			// 종료
			if (input.equalsIgnoreCase("x")) {
				System.out.println("이전 화면으로 이동합니다.");
				return;// 메서드 종료
			}

			int mode;

			try {
				mode = Integer.parseInt(input);
				if (mode < 1 || mode > 5) {
					System.out.println("잘못된 난이도 입니다. 다시선택해 주십시오.");
					continue;// 잘못된 입력으로 인해 다시 유저가 난이도 선택하는 위치로 이동
				}
			} catch (NumberFormatException e) {
				// 입력이 정수가 아닐경우
				System.out.println("잘못된 입력입니다. 숫자를 입력해 주십시오.");
				continue;// 잘못된 입력으로 인해 다시 유저가 난이도 선택하는 위치로 이동
			}

			switch (mode) {
			case 1:
				System.out.println("[덧셈,뺄셈]모드가 선택되었습니다.");
				for (int t = 3; t > 0; t--) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						System.out.println("대기중 오류발생");
						Thread.currentThread().interrupt();
					}
				}
				System.out.println("문제당 주어지는 시간은 120초 입니다.");
				for (int t = 3; t > 0; t--) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						System.out.println("대기중 오류발생");
						Thread.currentThread().interrupt();
					}
				}
				System.out.println("5초후 게임이 시작됩니다.");
				// 5초 카운트다운 사이클
				for (int i = 5; i > 0; i--) {
					System.out.println(i + "...");
					try {
						Thread.sleep(1000); // 1초 대기
					} catch (InterruptedException e) {
						System.out.println("카운트중 오류발생.");
						Thread.currentThread().interrupt();
					}
				}

				System.out.println("게임시작!");
				
				//사이클조정(문제를 몇문제 낼것인가)
				for (int i = 1; i <= 5; i++) {
					//랜덤함수 설정
					int first_number = generateRandomNumber(9);
					int second_number = generateRandomNumber(49);

					System.out.println("문제" + i);
					System.out.println(first_number + "+" + second_number + "=?");
					
					Callable<Integer>task = () -> {
						if(scanner.hasNextInt()) {
							return scanner.nextInt();
						}else {
							return null;
						}
					};
					Future<Integer> future = executor.submit(task);
					Integer playerAnswer = null;
					
                    try {
                        playerAnswer = future.get(120, TimeUnit.SECONDS); // 120초 대기
                    } catch (TimeoutException e) {
                        future.cancel(true); // 타임아웃 발생 시 태스크 취소
                        System.out.println("시간 초과! 정답은 " + (first_number + second_number) + "입니다.");
                    } catch (InterruptedException | ExecutionException e) {
                        System.out.println("오류 발생: " + e.getMessage());
                    }

                    int correctAnswer = first_number + second_number;

                    if (playerAnswer != null && playerAnswer.equals(correctAnswer)) {
                        System.out.println("정답입니다.");
                        score++; // 정답 점수 증가
                    } else if (playerAnswer != null) {
                        System.out.println("오답입니다. 정답은 " + correctAnswer + "입니다.");
                    }

                    for (int t = 3; t > 0; t--) {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            System.out.println("대기중 오류 발생");
                            Thread.currentThread().interrupt();
                        }
                    }
                }
				System.out.println("모든 문제가 완료되었습니다.");
				for (int t = 3; t > 0; t--) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						System.out.println("대기중 오류발생");
						Thread.currentThread().interrupt();
					}
				}
				System.out.println("총 맞추신 정답의 개수는5개 중에" + score + "개 입니다.");
				for (int t = 3; t > 0; t--) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						System.out.println("대기중 오류발생");
						Thread.currentThread().interrupt();
					}
				}
				System.out.println("수고하셨습니다.");
				for (int t = 3; t > 0; t--) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						System.out.println("대기중 오류발생");
						Thread.currentThread().interrupt();
					}
				}
				return;
			case 2:
				System.out.println("[곱셈]모드가 선택되었습니다.");
				for (int t = 3; t > 0; t--) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						System.out.println("대기중 오류발생");
						Thread.currentThread().interrupt();
					}
				}
				System.out.println("문제당 주어지는 시간은 120초 입니다.");
				for (int t = 3; t > 0; t--) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						System.out.println("대기중 오류발생");
						Thread.currentThread().interrupt();
					}
				}
				System.out.println("5초후 게임이 시작됩니다.");
				// 5초 카운트다운 사이클
				for (int i = 5; i > 0; i--) {
					System.out.println(i + "...");
					try {
						Thread.sleep(1000); // 1초 대기
					} catch (InterruptedException e) {
						System.out.println("카운트중 오류발생.");
						Thread.currentThread().interrupt();
					}
				}

				System.out.println("게임시작!");
				
				//사이클조정(문제를 몇문제 낼것인가)
				for (int i = 1; i <= 5; i++) {
					//랜덤함수 설정
					int first_number = generateRandomNumber(9);
					int second_number = generateRandomNumber(49);

					System.out.println("문제" + i);
					System.out.println(first_number + "*" + second_number + "=?");
					
					Callable<Integer>task = () -> {
						if(scanner.hasNextInt()) {
							return scanner.nextInt();
						}else {
							return null;
						}
					};
					Future<Integer> future = executor.submit(task);
					Integer playerAnswer = null;
					
                    try {
                        playerAnswer = future.get(120, TimeUnit.SECONDS); // 120초 대기
                    } catch (TimeoutException e) {
                        future.cancel(true); // 타임아웃 발생 시 태스크 취소
                        System.out.println("시간 초과! 정답은 " + (first_number * second_number) + "입니다.");
                    } catch (InterruptedException | ExecutionException e) {
                        System.out.println("오류 발생: " + e.getMessage());
                    }

                    int correctAnswer = first_number * second_number;

                    if (playerAnswer != null && playerAnswer.equals(correctAnswer)) {
                        System.out.println("정답입니다.");
                        score++; // 정답 점수 증가
                    } else if (playerAnswer != null) {
                        System.out.println("오답입니다. 정답은 " + correctAnswer + "입니다.");
                    }

                    for (int t = 3; t > 0; t--) {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            System.out.println("대기중 오류 발생");
                            Thread.currentThread().interrupt();
                        }
                    }
                }
				System.out.println("모든 문제가 완료되었습니다.");
				for (int t = 3; t > 0; t--) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						System.out.println("대기중 오류발생");
						Thread.currentThread().interrupt();
					}
				}
				System.out.println("총 맞추신 정답의 개수는5개 중에" + score + "개 입니다.");
				for (int t = 3; t > 0; t--) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						System.out.println("대기중 오류발생");
						Thread.currentThread().interrupt();
					}
				}
				System.out.println("수고하셨습니다.");
				for (int t = 3; t > 0; t--) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						System.out.println("대기중 오류발생");
						Thread.currentThread().interrupt();
					}
				}
				return;
			case 3:
				System.out.println("[나눗셈]모드가 선택되었습니다.");
				System.out.println("5초후 게임이 시작됩니다.");
				break;
			case 4:
				System.out.println("[곱셈,나눗셈]모드가 선택되었습니다.");
				System.out.println("5초후 게임이 시작됩니다.");
				break;
			case 5:
				System.out.println("[사칙연산]모드가 선택되었습니다.");
				System.out.println("5초후 게임이 시작됩니다.");
				break;
			default:
				System.out.println("잘못된 선택입니다.");
				break;
			}

		}

	}

}
