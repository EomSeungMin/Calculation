package com.Yami;

public class Hell {
	public void start() {
	System.out.println("Hell 난이도가 선택되었습니다.");
	}


}
