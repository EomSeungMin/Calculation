package com.Yami;

public class Inferno {
	public void start() {
	System.out.println("Inferno 난이도가 선택되었습니다.");
	}

}
