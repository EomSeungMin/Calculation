package com.Yami;

public class Very_hard {
	public void start() {
	System.out.println("Very hard 난이도가 선택되었습니다.");
	}
}
