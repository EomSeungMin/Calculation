package com.Yami;

public class Lunatic {
	public void start() {
	System.out.println("Lunatic 난이도가 선택되었습니다.");
	}

}
