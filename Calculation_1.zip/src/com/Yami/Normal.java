package com.Yami;

public class Normal {
	public void start() {
	System.out.println("Normal 난이도가 선택되었습니다.");
	}
}
