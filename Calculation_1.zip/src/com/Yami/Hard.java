package com.Yami;

public class Hard {
	public void start() {
	System.out.println("Hard 난이도가 선택되었습니다.");
	}


}
