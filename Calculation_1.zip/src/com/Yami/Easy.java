package com.Yami;

public class Easy {
	public void start() {
	System.out.println("Easy 난이도가 선택되었습니다.");
	}


}
