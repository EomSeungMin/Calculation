package com.Yami;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		//각 난이도 별 등장할 수치
//		int first_number = ((int)Math.random()*9+1);
//		int second_number = ((int)Math.random()*49+1);
//		int third_number = ((int)Math.random()*99+1);
//		int fourth_number = ((int)Math.random()*499+1);
//		int fifth_number = ((int)Math.random()*999+1);
//		int sixth_number = ((int)Math.random()*4999+1);
//		int seventh_number = ((int)Math.random()*9999+1);
//		int eighth_number = ((int)Math.random()*19999+1);
//		int ninth_number = ((int)Math.random()*49999+1);
//		int tenth_number = ((int)Math.random()*99999+1);
		
		Scanner scanner = new Scanner(System.in);//scanner라는 객체를 생성
		
		//난이도 선택을위한 무한 반복
		while(true) {
			//난이도 선택창
			System.out.println("난이도를 선택하십시오.(예 : Very easy를 원할경우 '2' 입력)");
			System.out.println("[1.Practice],[2.Very easy],[3.Easy],[4.Normal],[5.Hard]");
		    System.out.println("[6.Very Hard],[7.Hell],[8.Inferno],[9.Lunatic],[10.Holic]");
			System.out.println("종료를 원하시면 'x'를 입력해주세요.");
			
			//유저가 난이도 선택
		String input = scanner.nextLine().trim(); // 입력값에 불필요한 공백 제거
		
		
		if (input.equalsIgnoreCase("x")) {
			System.out.println("프로그램을 종료합니다.");
			break;// while 루프 종료
		}
		
		
		int difficulty;
		try {
			difficulty = Integer.parseInt(input);
		if (difficulty < 1 || difficulty >10) {
			System.out.println("잘못된 난이도 입니다. 다시선택해 주십시오.");
			continue;//잘못된 입력으로 인해 다시 유저가 난이도 선택하는 위치로 이동
			}
		} catch(NumberFormatException e) {
			// 입력이 정수가 아닐경우
			System.out.println("잘못된 입력입니다. 숫자를 입력해 주십시오.");
			continue;//잘못된 입력으로 인해 다시 유저가 난이도 선택하는 위치로 이동
		}

//		String difficultyName = "";
		
		switch (difficulty) {
		case 1:
//			difficultyName = "Practice";
			new Practice().start();
			break;
		case 2:
//			difficultyName = "Very easy";
			new Very_easy().start();	
			break;
		case 3:
//			difficultyName = "Easy";
			new Easy().start();
			break;
		case 4:
//			difficultyName = "Normal";
			new Normal().start();
			break;
		case 5:
//			difficultyName = "Hard";
			new Hard().start();
			break;
		case 6:
//			difficultyName = "Very hard";
			new Very_hard().start();
			break;
		case 7:
//			difficultyName = "Hell";
			new Hell().start();
			break;
		case 8:
//			difficultyName = "Inferno";
			new Inferno().start();
			break;
		case 9:
//			difficultyName = "Lunatic";
			new Lunatic().start();
			break;
		case 10:
//			difficultyName = "Holic";
			new Holic().start();
			break;

			
		}
		
//		System.out.println("선택한 난이도:" + difficultyName);
		
		
		
		}
		
		
		
		
		
		
		
		
		
		
	}
}
