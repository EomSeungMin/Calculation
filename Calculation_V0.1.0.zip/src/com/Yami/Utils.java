package com.Yami;

public class Utils {
	public static void countdown(int seconds) {
		for (int t = seconds; t > 0; t--) {
			System.out.println(t+"...");
			try {
				Thread.sleep(1000);//1초 대기(1000밀리초 대기)
			} catch (InterruptedException e) {
				System.out.println("대기중 오류 발생");
				Thread.currentThread().interrupt();
			}
		}
	}
	
	public static void count(int seconds) {
		for (int t = seconds; t > 0; t--) {
			try {
				Thread.sleep(1000);//1초 대기(1000밀리초 대기)
			} catch (InterruptedException e) {
				System.out.println("대기중 오류 발생");
				Thread.currentThread().interrupt();
			}
		}
	}

}
