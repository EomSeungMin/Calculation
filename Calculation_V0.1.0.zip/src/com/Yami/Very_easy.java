package com.Yami;

import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class Very_easy {
	private Random random = new Random();
	private int score = 0; // 정답 점수

//	private int generateRandomNumber(int upperBound) {
//		return(int)(Math.random()*upperBound)+1;
//	}
	private int generateRandomNumber(int upperBound) {
		return random.nextInt(upperBound) + 1;
	}

	private char getRandomOperator() {
		return random.nextBoolean() ? '+' : '-';
	}

	private char getRandomOperator1() {
		return random.nextBoolean() ? '*' : '÷';
	}

	private char getRandomOperator2() {
		int randomIndex = random.nextInt(4);
		switch (randomIndex) {
		case 0:
			return '+';
		case 1:
			return '-';
		case 2:
			return '*';
		case 3:
			return '÷';
		default:
			throw new IllegalStateException("Unexpected value: " + randomIndex);
		}
	}

	private double roundToTwoDecimalPlaces(double value) {
		return Math.round(value * 100.0) / 100.0;
	}

	private double getCorrectAnswer(double first_number, double second_number, char operator) {
		switch (operator) {
		case '+':
			return first_number + second_number;
		case '-':
			return first_number - second_number;
		default:
			throw new IllegalArgumentException("Unsupported operator: " + operator);
		}
	}

	private double getCorrectAnswer1(double first_number, double second_number, char operator1) {
		switch (operator1) {
		case '*':
			return first_number * second_number;
		case '÷':
			return first_number / second_number;

		default:
			throw new IllegalArgumentException("Unsupported operator: " + operator1);
		}
	}

	private double getCorrectAnswer2(double first_number, double second_number, char operator2) {
		switch (operator2) {
		case '+':
			return first_number + second_number;
		case '-':
			return first_number - second_number;
		case '*':
			return first_number * second_number;
		case '÷':
			return first_number / second_number;

		default:
			throw new IllegalArgumentException("Unsupported operator: " + operator2);
		}
	}

	public void start() {
		System.out.println("Very easy 난이도가 선택되었습니다.");
		System.out.println("게임 모드를 선택해 주십시오. (예 : 사칙연산을 원하신다면 '4'를 입력)");
		System.out.println("[1.덧셈,뺄셈],[2.곱셈],[3.나눗셈],[4.곱셈,나눗셈],[5.사칙연산]");
		System.out.println("이전화면으로 이동하시고 싶다면 'x'를입력해 주십시오.");

		Scanner scanner = new Scanner(System.in);
		ExecutorService executor = Executors.newSingleThreadExecutor();

		while (true) {
			String input = scanner.nextLine().trim();
			// 종료
			if (input.equalsIgnoreCase("x")) {
				System.out.println("이전 화면으로 이동합니다.");
				return;// 메서드 종료
			}

			int mode;

			try {
				mode = Integer.parseInt(input);
				if (mode < 1 || mode > 5) {
					System.out.println("잘못된 난이도 입니다. 다시선택해 주십시오.");
					continue;// 잘못된 입력으로 인해 다시 유저가 난이도 선택하는 위치로 이동
				}
			} catch (NumberFormatException e) {
				// 입력이 정수가 아닐경우
				System.out.println("잘못된 입력입니다. 숫자를 입력해 주십시오.");
				continue;// 잘못된 입력으로 인해 다시 유저가 난이도 선택하는 위치로 이동
			}

			switch (mode) {
			case 1:

				System.out.println("[덧셈,뺄셈]모드가 선택되었습니다.");
				Utils.count(3);
				System.out.println("문제는 총 5문제 입니다.");
				Utils.count(3);
				System.out.println("문제당 주어지는 시간은 120초 입니다.");
				Utils.count(3);
				System.out.println("5초후 게임이 시작됩니다.");
				// 5초 카운트다운 사이클
				Utils.countdown(5);

				System.out.println("게임시작!");

				// 사이클조정(문제를 몇문제 낼것인가)
				for (int i = 1; i <= 5; i++) {
					// 랜덤함수 설정
					double first_number = generateRandomNumber(99);
					double second_number = generateRandomNumber(99);
					char operator = getRandomOperator(); // 랜덤 연산자 선택 ('+','-')
					System.out.println("문제" + i);
					System.out.println(first_number + " " + operator + " " + second_number + "=?");

					Callable<Double> task = () -> {
						if (scanner.hasNextDouble()) {
							return scanner.nextDouble();
						} else {
							return null;
						}
					};
					Future<Double> future = executor.submit(task);
					Double playerAnswer = null;

					try {
						playerAnswer = future.get(120, TimeUnit.SECONDS); // 120초 대기
					} catch (TimeoutException e) {
						future.cancel(true); // 타임아웃 발생 시 태스크 취소
						System.out.println(
								"시간 초과! 정답은 " + (first_number + " " + operator + " " + second_number) + "입니다.");
					} catch (InterruptedException | ExecutionException e) {
						System.out.println("오류 발생: " + e.getMessage());
					}

					double correctAnswer = getCorrectAnswer(first_number, second_number, operator);

					if (playerAnswer != null && Math.abs(playerAnswer - correctAnswer) < 0.01) {
						System.out.println("정답입니다.");
						score++; // 정답 점수 증가
					} else if (playerAnswer != null) {
						System.out.println("오답입니다. 정답은 " + correctAnswer + "입니다.");
					}

				}
				System.out.println("모든 문제가 완료되었습니다.");
				Utils.count(3);
				System.out.println("총 맞추신 정답의 개수는5개 중에" + score + "개 입니다.");
				Utils.count(3);
				System.out.println("수고하셨습니다.");
				Utils.count(3);
				return;
			case 2:
				System.out.println("[곱셈]모드가 선택되었습니다.");
				Utils.count(3);
				System.out.println("문제는 총 5문제 입니다.");
				Utils.count(3);
				System.out.println("문제당 주어지는 시간은 120초 입니다.");
				Utils.count(3);
				System.out.println("5초후 게임이 시작됩니다.");
				// 5초 카운트다운 사이클
				Utils.countdown(5);

				System.out.println("게임시작!");

				// 사이클조정(문제를 몇문제 낼것인가)
				for (int i = 1; i <= 5; i++) {
					// 랜덤함수 설정
					double first_number = generateRandomNumber(19);
					double second_number = generateRandomNumber(49);

					System.out.println("문제" + i);
					System.out.println(first_number + "*" + second_number + "=?");

					Callable<Double> task = () -> {
						if (scanner.hasNextDouble()) {
							return scanner.nextDouble();
						} else {
							return null;
						}
					};
					Future<Double> future = executor.submit(task);
					Double playerAnswer = null;

					try {
						playerAnswer = future.get(120, TimeUnit.SECONDS); // 120초 대기
					} catch (TimeoutException e) {
						future.cancel(true); // 타임아웃 발생 시 태스크 취소
						System.out.println("시간 초과! 정답은 " + (first_number * second_number) + "입니다.");
					} catch (InterruptedException | ExecutionException e) {
						System.out.println("오류 발생: " + e.getMessage());
					}

					double correctAnswer = first_number * second_number;

					if (playerAnswer != null && Math.abs(playerAnswer - correctAnswer) < 0.01) {
						System.out.println("정답입니다.");
						score++; // 정답 점수 증가
					} else if (playerAnswer != null) {
						System.out.println("오답입니다. 정답은 " + correctAnswer + "입니다.");
					}

					Utils.count(3);
				}
				System.out.println("모든 문제가 완료되었습니다.");
				Utils.count(3);
				System.out.println("총 맞추신 정답의 개수는5개 중에" + score + "개 입니다.");
				Utils.count(3);
				System.out.println("수고하셨습니다.");
				Utils.count(3);
				return;
			case 3:
				System.out.println("[나눗셈]모드가 선택되었습니다.");
				Utils.count(3);
				System.out.println("문제는 총 5문제 입니다.");
				Utils.count(3);
				System.out.println("문제당 주어지는 시간은 120초 입니다.");
				Utils.count(3);
				System.out.println("소수점이 존재할경우");
				System.out.println("소수점은 두번째자리까지 표기합니다.");
				Utils.count(3);
				System.out.println("소수점이 세자리가 넘어가면");
				System.out.println("세번째자리를 기준으로 반올림 처리합니다.");
				Utils.count(3);
				System.out.println("5초후 게임이 시작됩니다.");
				// 5초 카운트다운 사이클
				Utils.countdown(5);

				System.out.println("게임시작!");

				// 사이클조정(문제를 몇문제 낼것인가)
				for (int i = 1; i <= 5; i++) {
					// 랜덤함수 설정
					double first_number = generateRandomNumber(49);
					double second_number = generateRandomNumber(9);

					System.out.println("문제" + i);
					System.out.println(first_number + "÷" + second_number + "=?");

					Callable<Double> task = () -> {
						if (scanner.hasNextDouble()) {
							return scanner.nextDouble();
						} else {
							return null;
						}
					};
					Future<Double> future = executor.submit(task);
					Double playerAnswer = null;

					try {
						playerAnswer = future.get(120, TimeUnit.SECONDS); // 120초 대기
					} catch (TimeoutException e) {
						future.cancel(true); // 타임아웃 발생 시 태스크 취소
						System.out.println("시간 초과! 정답은 " + (first_number / second_number) + "입니다.");
					} catch (InterruptedException | ExecutionException e) {
						System.out.println("오류 발생: " + e.getMessage());
					}

					double correctAnswer = first_number / second_number;

					if (playerAnswer != null && Math.abs(playerAnswer - correctAnswer) < 0.01) {
						System.out.println("정답입니다.");
						score++; // 정답 점수 증가
					} else if (playerAnswer != null) {
						System.out.println("오답입니다. 정답은 " + correctAnswer + "입니다.");
					}

					Utils.count(3);
				}
				System.out.println("모든 문제가 완료되었습니다.");
				Utils.count(3);
				System.out.println("총 맞추신 정답의 개수는5개 중에" + score + "개 입니다.");
				Utils.count(3);
				System.out.println("수고하셨습니다.");
				Utils.count(3);
				return;
			case 4:
				System.out.println("[곱셈,나눗셈]모드가 선택되었습니다.");
				Utils.count(3);
				System.out.println("문제는 총 5문제 입니다.");
				Utils.count(3);
				System.out.println("소수점이 존재할경우");
				System.out.println("소수점은 두번째자리까지 표기합니다.");
				Utils.count(3);
				System.out.println("소수점이 세자리가 넘어가면");
				System.out.println("세번째자리를 기준으로 반올림 처리합니다.");
				Utils.count(3);
				System.out.println("문제당 주어지는 시간은 120초 입니다.");
				Utils.count(3);
				System.out.println("5초후 게임이 시작됩니다.");
				// 5초 카운트다운 사이클
				Utils.countdown(5);

				System.out.println("게임시작!");

				// 사이클조정(문제를 몇문제 낼것인가)
				for (int i = 1; i <= 5; i++) {
					// 랜덤함수 설정
					double first_number = generateRandomNumber(29);
					double second_number = generateRandomNumber(29);
					char operator1 = getRandomOperator1(); // 랜덤 연산자 선택 ('*','/')
					System.out.println("문제" + i);
					System.out.println(first_number + " " + operator1 + " " + second_number + "=?");

					Callable<Double> task = () -> {
						if (scanner.hasNextDouble()) {
							return scanner.nextDouble();
						} else {
							return null;
						}
					};
					Future<Double> future = executor.submit(task);
					Double playerAnswer = null;

					try {
						playerAnswer = future.get(120, TimeUnit.SECONDS); // 120초 대기
					} catch (TimeoutException e) {
						future.cancel(true); // 타임아웃 발생 시 태스크 취소
						System.out.println(
								"시간 초과! 정답은 " + (first_number + " " + operator1 + " " + second_number) + "입니다.");
					} catch (InterruptedException | ExecutionException e) {
						System.out.println("오류 발생: " + e.getMessage());
					}

					double correctAnswer = getCorrectAnswer1(first_number, second_number, operator1);

					if (playerAnswer != null && Math.abs(playerAnswer - correctAnswer) < 0.01) {
						System.out.println("정답입니다.");
						score++; // 정답 점수 증가
					} else if (playerAnswer != null) {
						System.out.println("오답입니다. 정답은 " + correctAnswer + "입니다.");
					}

					Utils.count(3);
				}
				System.out.println("모든 문제가 완료되었습니다.");
				Utils.count(3);
				System.out.println("총 맞추신 정답의 개수는5개 중에" + score + "개 입니다.");
				Utils.count(3);
				System.out.println("수고하셨습니다.");
				Utils.count(3);
				return;
			case 5:
				System.out.println("[사칙연산]모드가 선택되었습니다.");
				Utils.count(3);
				System.out.println("문제는 총 5문제 입니다.");
				Utils.count(3);
				System.out.println("소수점이 존재할경우");
				System.out.println("소수점은 두번째자리까지 표기합니다.");
				Utils.count(3);
				System.out.println("소수점이 세자리가 넘어가면");
				System.out.println("세번째자리를 기준으로 반올림 처리합니다.");
				Utils.count(3);
				System.out.println("문제당 주어지는 시간은 120초 입니다.");
				Utils.count(3);
				System.out.println("5초후 게임이 시작됩니다.");
				// 5초 카운트다운 사이클
				Utils.countdown(5);

				System.out.println("게임시작!");

				// 사이클조정(문제를 몇문제 낼것인가)
				for (int i = 1; i <= 5; i++) {
					// 랜덤함수 설정
					double first_number = generateRandomNumber(29);
					double second_number = generateRandomNumber(29);
					char operator2 = getRandomOperator2(); // 랜덤 연산자 선택 ('+','-','*','/')
					System.out.println("문제" + i);
					System.out.println(first_number + " " + operator2 + " " + second_number + "=?");

					Callable<Double> task = () -> {
						if (scanner.hasNextDouble()) {
							return scanner.nextDouble();
						} else {
							return null;
						}
					};
					Future<Double> future = executor.submit(task);
					Double playerAnswer = null;

					try {
						playerAnswer = future.get(120, TimeUnit.SECONDS); // 120초 대기
					} catch (TimeoutException e) {
						future.cancel(true); // 타임아웃 발생 시 태스크 취소
						System.out.println(
								"시간 초과! 정답은 " + (first_number + " " + operator2 + " " + second_number) + "입니다.");
					} catch (InterruptedException | ExecutionException e) {
						System.out.println("오류 발생: " + e.getMessage());
					}

					double correctAnswer = getCorrectAnswer2(first_number, second_number, operator2);

					if (playerAnswer != null && Math.abs(playerAnswer - correctAnswer) < 0.01) {
						System.out.println("정답입니다.");
						score++; // 정답 점수 증가
					} else if (playerAnswer != null) {
						System.out.println("오답입니다. 정답은 " + correctAnswer + "입니다.");
					}

					Utils.count(3);
				}
				System.out.println("모든 문제가 완료되었습니다.");
				Utils.count(3);
				System.out.println("총 맞추신 정답의 개수는5개 중에" + score + "개 입니다.");
				Utils.count(3);
				System.out.println("수고하셨습니다.");
				Utils.count(3);
				return;
			default:
				System.out.println("잘못된 선택입니다.");
				break;
			}

		}

	}

}
