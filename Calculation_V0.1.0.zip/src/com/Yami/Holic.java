package com.Yami;

public class Holic {
	public void start() {
	System.out.println("Holic 난이도가 선택되었습니다.");
	}

}
